import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <nav className={`lp-navbar${scrolled ? " lp-navbar--scrolled" : ""}`}>
      <div className="lp-navbar__inner">
        <div className="lp-navbar__logo" onClick={() => scrollTo("home")}>
          <span className="lp-navbar__hex">⬡</span>
          <span className="lp-navbar__brand">PlaceHub</span>
        </div>
        <div className="lp-navbar__links">
          {["home", "about", "companies", "contact"].map((s) => (
            <button
              key={s}
              className="lp-navbar__link"
              onClick={() => scrollTo(s)}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
        <button className="lp-navbar__login" onClick={() => navigate("/login")}>
          Login
        </button>
      </div>
    </nav>
  );
}