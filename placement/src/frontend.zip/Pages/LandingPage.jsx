import Navbar from "../Components/Navbar";
import Hero from "../Components/Hero";
import About from "../Components/About";
import Companies from "../Components/Companies";
import Contact from "../Components/Contact";
import Footer from "../Components/Footer";
import "./LandingPage.css";

export default function LandingPage() {
  return (
    <div className="lp-root">
      <Navbar />
      <Hero />
      <About />
      <Companies />
      <Contact />
      <Footer />
    </div>
  );
}